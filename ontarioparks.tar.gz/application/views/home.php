<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Indie+Flower&display=swap');
</style>
<div class="container-fluid home-banner">
	<div class="hero-section position-relative">
		<div class="row align-items-center">
			<div class="col-md-12 text-white">
				<!-- <h1>Ontario Parks</h1> -->
				<div class="home-title indie-flower-regular">
					<p class="mb-0">Your all-in-one</p>
					<p class="mb-0">Ontario Parks</p>
					<p>camping buddy!</p>
				</div>
			</div>
		</div>
	</div>
	<a href="<?=base_url('auth/signup')?>" class="btn-get-started">Get Started</a>
</div>