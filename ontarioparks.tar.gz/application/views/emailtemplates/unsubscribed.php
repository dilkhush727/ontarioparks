
<div class="row pt-5">
<div class="col-md-6" style="margin:0 auto;">
<table class="table" style="border: solid 1px #c5c5c5;background: #f9f9f9;">
  <tr>
    <td style="border-bottom:none"><h1 style="background: #fde428;padding: 3px 10px;">Unsubscribe Successful!</h1></td>
  </tr>
  <tr>
    <td style="border-bottom:none;padding: 0 23px 0;">You have successfully unsubscribed from Eazedesk's email list.</td>
  </tr>
  <tr>
    <td style="border-bottom:none;padding: 0 23px 0;">You will no longer receive product updates and announcements.</td>
  </tr>
</table>
</div>
</div>